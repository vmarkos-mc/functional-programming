# in-class-mor/dealing.py

import itertools as it
import random
import math

suits = ['C', 'D', 'H', 'S']
numbers = [str(i) for i in range(2, 11)] + ['J', 'Q', 'K', 'A']

# Building a deck

# 001: Nested loop
# deck = []
# for s in suits:
#     for n in numbers:
#         deck.append(f"{n} of {s}")
# print(deck)

# 002: List comprehension
# deck = [f"{n} of {s}" for n in numbers for s in suits]
# print(deck)

# 003: Generator expression
# deck = (f"{n} of {s}" for n in numbers for s in suits)
# print(deck)

# 004: As an iterator (dummy way)
# deck = iter([f"{n} of {s}" for n in numbers for s in suits])
# print(deck)

# 005: As a product of iterables
# deck = it.product(suits, numbers) # `it.product()` computes the Cartesian product of its inputs.
# print(deck)

def create_deck():
    return it.product(suits, numbers)

def shuffle(deck):
    deck_list = list(deck)
    random.shuffle(deck_list)
    return iter(deck_list)

def print_deck(deck, n_cards = math.inf):
    i = 0
    deck = it.tee(deck, 1)[0]
    while i < n_cards:
        try:
            print(next(deck))
        except StopIteration:
            return
        i += 1

def cut(deck, cut_at):
    first, rest = it.tee(deck, 2) # We need two independent copies of the deck to work with, otherwise the deck will be exhausted
    top = it.islice(first, cut_at) # Get the "first" part of the deck, until `cut_at`
    bottom = it.islice(rest, cut_at, None) # Get the "rest" of the deck, after `cut_at`
    return it.chain(bottom, top)

def deal(deck, n_hands = 4, hand_size = 5):
    decks = [deck] * hand_size
    return it.islice(zip(*decks), n_hands)

def main():
    deck = create_deck()
    deck = shuffle(deck)
    # cut_deck = cut(deck, 3)
    hands = deal(deck)
    while True:
        try:
            print(next(hands))
        except StopIteration:
            break
    i = 0
    while True:
        try:
            next(deck)
            i += 1
        except StopIteration:
            break
    print(i)
    # print_deck(deck, 5)
    # print("-" * 20)
    # print_deck(cut_deck, 5)

if __name__ == "__main__":
    main()