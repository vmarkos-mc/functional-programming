module Countdown where

-- Exercise 2.1

data Op     = Add | Sub | Mul | Div
    deriving Show

data Expr   = Val Int                           -- Leaf nodes, i.e., positive integers.
            | Node Expr Op Expr                 -- Internal node, with left and right sub-expressions
    deriving Show

-- Exercise 2.2

-- Validity in the sense of operators always resulting to positive integers.
valid :: Op -> Int -> Int -> Bool
valid Add _ _ = True
valid Sub x y = x > y
valid Mul _ _ = True
valid Div x y = mod x y == 0                    -- infix --> x `mod` y == 0

apply :: Op -> Int -> Int -> Int
apply Add x y = x + y
apply Sub x y = x - y
apply Mul x y = x * y
apply Div x y = x `div` y

nesplit :: [a] -> [a] -> [([a], [a])]
nesplit [] _ = []
nesplit [x] _ = []
nesplit (x:xs) buf = (y, xs) : nesplit xs y
    where y = buf ++ [x]

subbags :: [a] -> [[a]]
subbags [] = [[]]                               -- Since the empty list is a sublist of everything
subbags (x:xs) = [x:y | y <- subbags xs] ++ subbags xs -- This is not correct, since we ignore permutations

permutations :: [a] -> [[a]]
permutations (x:xs) = [insert x y | y <- permutations xs]
    where
        insert x (y:ys) = []
        -- return a list where x has been inserted in all possible places in list y
