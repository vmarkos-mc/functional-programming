# in-class/dealing.py

import random
import itertools as it

suits = ["C", "D", "H", "S"]
ranks = [str(x) for x in range(2, 11)] + ["J", "Q", "K", "A"]

# cards = ((s, r) for s in suits for r in ranks)

cards = it.product(suits, ranks) # .product() computes the Cartesian Product of its arguments

def shuffle(deck):
    deck_list = list(deck)
    random.shuffle(deck_list)
    return iter(deck_list)

def cut(deck, pos):
    pass

def deal(deck, hand_size=5, num_of_hands=4):
    pass

print(shuffle(cards))