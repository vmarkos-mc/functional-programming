# in-class/grouping.py

from psutil import Process
import time
import os
import itertools as it
# import random

def group_by(numbers, m):
    """Assuming that len(numbers) is a multiple of m"""
    n = len(numbers)
    return [tuple(numbers[(i * m):(i * m + m)]) for i in range(n // m)]

def igroup_by(numbers, m):
    number_iter = iter(numbers)
    number_iters = [number_iter] * m
    return zip(*number_iters)

# numbers           == [1, 2, 3, 4, 5, 6]
# m                 == 2
# number_iter       == <iterator object @ 0x000124> --> (1, 2, 3, 4, 5, 6)
# number_iters      == [<iterator object @ 0x000124>, <iterator object @ 0x000124>]
# zip(*number_iters)== ...
#   1. zip triggers the first iterator for the first number it has to provide --> 1
#   2. Then, <iterator object @ 0x000124> --> (2, 3, 4, 5, 6)
#   3. zip triggers the second iterator for its own first element --> 2
#   4. So, <iterator object @ 0x000124> --> (3, 4, 5, 6)
#   5. zip triggers the first iterator for the first number it has to provide --> 3
#   6. Then, <iterator object @ 0x000124> --> (4, 5, 6)
#   7. zip triggers the second iterator for its own first element --> 4
#   8. So, <iterator object @ 0x000124> --> (5, 6)

def test(fn, nums, m):
    start = time.time_ns()
    grouped = fn(nums, m)
    end = time.time_ns()
    exec_time = (end - start) / 10 ** 9
    memory = Process(os.getpid()).memory_info().rss / 1024 ** 2
    print(f"Memory allocated: {memory} MBs")
    print(f"Execution time  : {exec_time} s.")

if __name__ == "__main__":
    n = 10 ** 12
    NUMS = range(n)
    m = 10
    # test(group_by, NUMS, m)
    # print(group_by(NUMS, m))
    # test(igroup_by, NUMS, m)
    i = 0
    groups = igroup_by(NUMS, m)
    while i < 1000:
        print(next(groups))
        i += 1