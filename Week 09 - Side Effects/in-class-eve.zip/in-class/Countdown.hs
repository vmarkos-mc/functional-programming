module Countdown where

-- Exercise 2.1

data Op = Add | Sub | Mul | Div
    deriving Show                                   -- Just to print stuff  

data Expr   = Num Int                               -- Base case: Just a number
            | Iok Expr Op Expr                      -- Recursive case: Expr + Expr or Expr * Expr
    deriving Show                                   -- Just to print stuff

-- Exercise 2.2

valid :: Op -> Int -> Int -> Bool
valid Add x y = True                                -- Adding two positives yields a positive int
valid Sub x y = x - y > 0                           -- x - y should be positive to proceed
valid Mul x y = True                                -- positive * positive == positive
valid Div x y = mod x y == 0                        -- x divides y iff x mod y == 0
-- valid Div x y = x `mod` y == 0

apply :: Op -> Int -> Int -> Int
apply Add x y = x + y
apply Sub x y = x - y
apply Mul x y = x * y
apply Div x y = x `div` y                           -- `div x y` also works

{--
nesplit [1, 2, 3, 4] == [([1], [2, 3, 4]), ([1, 2], [3, 4]), ([1, 2, 3], [4])]
--}

-- Implementation using two arguments
-- nesplit :: [a] -> [a] -> [([a], [a])]
-- nesplit [] _ = []
-- nesplit [x] _ = []
-- nesplit (x:xs) buf = (y, xs) : nesplit xs y
--     where y = buf ++ [x]

-- Implementation with auxiliary function
nesplit :: [a] -> [([a], [a])]
nesplit l = bufNesplit l []
    where
        bufNesplit [] _         = []
        bufNesplit [x] _        = []
        bufNesplit (x:xs) buf   = (y, xs) : bufNesplit xs y
            where y = buf ++ [x]

-- Homework!
split :: [a] -> [a] -> [([a], [a])]
split [] _ = []
-- split [x] _ = [([], [x])]
split (x:xs) buf = (y, xs) : split xs y
    where y = buf ++ [x]