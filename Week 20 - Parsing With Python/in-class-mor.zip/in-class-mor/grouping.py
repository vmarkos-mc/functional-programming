# import random
import time
import psutil
import os
import itertools as it

def group(numbers, m):
    if len(numbers) % m != 0:
        raise ValueError(f"`numbers` length ({len(numbers)}) should be a multiple of `m` ({m}).")
    groups = []
    while numbers:
        temp_group = []
        for i in range(m):
            temp_group.append(numbers[i])
        groups.append(tuple(temp_group))
        numbers = numbers[m:]
    return groups

def igroup(numbers, m):
    # Same as `group()` just using iterators.
    iterator = iter(numbers)
    iterators = [iterator] * m
    return zip(*iterators)

def test(fn, ns, m):
    start = time.time_ns()
    groups = fn(ns, m)
    # while True:
    #     print(next(groups))
    # print(list(groups))
    end = time.time_ns()
    exec_time = (end - start) / 10 ** 9
    process = psutil.Process(os.getpid())
    memory_consumed = process.memory_info().rss / 1024 ** 2
    print(f"Execution time : {exec_time}s")
    print(f"Memory Consumed: {memory_consumed} MB")

if __name__ == "__main__":
    NUMBERS = range(10 ** 150)
    m = 5
    test(igroup, NUMBERS, m)